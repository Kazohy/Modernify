package net.kazohy.guioverhaul.listener;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.fabricmc.fabric.api.networking.v1.PacketSender;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;


import static net.kazohy.guioverhaul.screen.CustomTitleScreen.takeScreenshot;

public class WorldCreationListener {
    private static int ticksRemaining = -1;

    public static void startCountdown(int ticks) {
        ticksRemaining = ticks;
    }

    private static boolean newWorldCreated = false;

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (ticksRemaining > 0) {
                ticksRemaining--;
            } else if (ticksRemaining == 0) {
                takeScreenshot(client);
                ticksRemaining = -1; // Reset
            }
        });
        ServerLifecycleEvents.SERVER_STARTED.register(WorldCreationListener::onWorldCreation);
        ServerPlayConnectionEvents.JOIN.register(WorldCreationListener::onPlayerJoin);
    }

    public static boolean onPlayerJoin(ServerPlayNetworkHandler handler, PacketSender sender, MinecraftServer server) {
        ServerPlayerEntity player = handler.player;

        System.out.println(player.getName().getString() + " has joined the world!");

        if (newWorldCreated) {
            newWorldCreated = false;
            WorldCreationListener.startCountdown(100);
            MinecraftClient client = MinecraftClient.getInstance();
            takeScreenshot(client);
            return true;
        } else {
            return false;
        }
    }

    private static void onWorldCreation(MinecraftServer server) {
        newWorldCreated = true;
        System.out.println("World is being created (server started)");
    }

}